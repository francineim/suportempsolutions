# app/email_system/__init__.py
from .email_service import enviar_email, enviar_email_teste

